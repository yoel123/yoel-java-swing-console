package ymain;


import yconsole.yconsole_action;
import yconsole.yconsole_frame;

public class main {

	public static void main(String[] args) {
		
		yconsole_frame ycf = new yconsole_frame("test",new test_app());
		ycf.yshow();
	}

}
